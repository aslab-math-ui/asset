# Studi Kasus: Analisis Data Perawatan Pasien RS Sehat Selalu

Praktikum Pengantar Sains Data - Pemahaman Analisis Data dengan Excel

## Biodata

**Nama**        : [Nama Lengkap Mahasiswa]  
**NPM**         : [NPM Mahasiswa]  
**Kelas**       : [Kelas Praktikum PSD]  
**Dosen**       : [Nama Dosen Pengampu]  

## Data Tugas

**Judul Dataset**       : Healthcare Analytics Dataset  
**Sumber Dataset**      : Maven Analytics   
**Tautan Dataset**      : [https://mavenanalytics.io/data-playground/hospital-patient-records](https://mavenanalytics.io/data-playground/hospital-patient-records)  
**Kata Kunci Dataset**  : `Hospital Patient Records dataset maven analytics`

### Folder Lampiran

**Format**              : `.xlsx` (Excel)  
**Tautan Web**          : -  (jika pakai google sheets)
**Tautan Video**        : [https://youtu.be/XXXXXXXXXXX](https://youtu.be/XXXXXXXXXXX)  
**File Lainnya**        : -  (jika ada .pptx atau .pdf)

### Deskripsikan Dataset

Dataset ini berisi catatan perawatan pasien fiktif dari "RS Sehat Selalu". Setiap baris merepresentasikan satu kali kunjungan atau perawatan pasien. Informasi yang terkandung di dalamnya mencakup detail demografis pasien (usia, jenis kelamin), detail medis (tipe admisi, hasil tes), detail perawatan (lama dirawat, prosedur utama), dan detail biaya (total tagihan, status asuransi). Dataset ini memiliki potensi besar untuk menemukan pola dalam perawatan pasien, efisiensi rumah sakit, dan analisis biaya.

## Pertanyaan Bisnis

Analisis ini bertujuan untuk membantu manajemen "RS Sehat Selalu" memahami operasional mereka dengan lebih baik. Pertanyaan utama yang ingin dijawab adalah:

1.  Berapa banyak pasien yang dirawat atau dirawat kembali (*readmitted*) dari waktu ke waktu?
2.  Berapa lama rata-rata pasien dirawat di rumah sakit, dan apakah ada perbedaan signifikan antar departemen?
3.  Berapa biaya rata-rata per kunjungan, dan bagaimana perbandingannya antara pasien yang menggunakan asuransi dan yang tidak?
4.  Prosedur medis apa yang paling sering dilakukan dan paling banyak ditanggung oleh asuransi?

## Proses Analisis

Analisis dilakukan sepenuhnya menggunakan Microsoft Excel dengan alur kerja sebagai berikut:

1.  **Persiapan & Transformasi Data:**
    * Data mentah dari `.csv` diimpor dan diubah menjadi **Excel Table** untuk memudahkan manipulasi.
    * Dilakukan pembersihan data pada kolom `Room_Num` untuk memisahkan nomor lantai dan nomor kamar.
    * Dibuat dua **kolom turunan**:
        * `Length_of_Stay`: Menghitung lama perawatan dari tanggal masuk dan keluar.
        * `Patient_Category`: Mengklasifikasikan pasien menjadi "Anak", "Dewasa", atau "Lansia" menggunakan fungsi `IF` pada kolom usia.

2.  **Analisis Agregat dengan Pivot Table:**
    * Dibuat beberapa **Pivot Table** untuk meringkas data.
    * *Pivot Table* pertama digunakan untuk menghitung **jumlah pasien** dan **jumlah pasien yang dirawat kembali** (*readmitted*), yang dikelompokkan (*grouped*) berdasarkan bulan dan tahun.
    * *Pivot Table* kedua digunakan untuk menghitung **rata-rata lama perawatan** (`Average of Length_of_Stay`) dan **rata-rata biaya** (`Average of Billing_Amount`) untuk setiap departemen.
    * *Pivot Table* ketiga digunakan untuk menghitung **frekuensi prosedur** yang ditanggung asuransi (`Insurance_Claimed`).

3.  **Dashboard & Visualisasi Interaktif:**
    * Dibuat sebuah *sheet* **Dashboard** yang berisi tiga **Pivot Chart** dan dua **Slicer**.
    * **Line Chart** digunakan untuk memvisualisasikan tren jumlah pasien dari waktu ke waktu.
    * **Bar Chart** digunakan untuk membandingkan rata-rata biaya per departemen.
    * **Pie Chart** digunakan untuk menunjukkan proporsi status klaim asuransi.
    * **Slicer** untuk `Department` dan `Patient_Category` ditambahkan dan dihubungkan ke semua *chart* untuk memungkinkan analisis interaktif. Judul *chart* juga dibuat dinamis agar berubah sesuai pilihan *slicer*.

## Wawasan yang Diperoleh

Berdasarkan analisis yang telah dilakukan, ditemukan beberapa wawasan kunci untuk manajemen "RS Sehat Selalu":

1.  **Tren Perawatan Pasien**: Terdapat puncak jumlah pasien yang dirawat pada kuartal ketiga (Juli-September), yang kemungkinan berhubungan dengan musim penyakit tertentu. Tingkat *readmission* (perawatan kembali) paling tinggi terjadi pada pasien kategori "Lansia", menunjukkan perlunya program perawatan pasca-opname yang lebih baik untuk demografi ini.

2.  **Efisiensi Perawatan**: Rata-rata lama perawatan pasien adalah **8.5 hari**. Departemen "General Medicine" memiliki rata-rata perawatan terlama (12 hari), sementara "Surgery" memiliki rata-rata tercepat (5 hari). Ini bisa menjadi dasar untuk evaluasi efisiensi prosedur di setiap departemen.

3.  **Analisis Biaya**: Biaya rata-rata per kunjungan adalah **Rp 25.500.000**. Menariknya, rata-rata tagihan untuk pasien yang menggunakan asuransi (Rp 28.000.000) lebih tinggi daripada pasien yang membayar sendiri (Rp 21.000.000). Ini memerlukan investigasi lebih lanjut mengenai skema penagihan.

4.  **Prosedur & Asuransi**: Prosedur "Normal Delivery" adalah yang paling sering dilakukan. Sekitar **85%** dari semua prosedur berhasil diklaim oleh asuransi, menunjukkan proses administrasi klaim yang sudah cukup baik.

## Saran & Rekomendasi

Berdasarkan wawasan di atas, berikut adalah beberapa saran strategis yang dapat dipertimbangkan oleh manajemen "RS Sehat Selalu" untuk perbaikan operasional dan finansial:

1.  **Mengantisipasi Lonjakan Pasien Kuartal Ketiga:**
    * **Rekomendasi:** Menyiapkan sumber daya tambahan (staf, kamar, obat-obatan) menjelang periode Juli-September untuk mengantisipasi lonjakan jumlah pasien tahunan dan menjaga kualitas layanan.

2.  **Program Perawatan Pasca-Opname untuk Lansia:**
    * **Rekomendasi:** Mengembangkan program perawatan atau pemantauan khusus pasca-opname untuk pasien kategori "Lansia" guna menekan angka *readmission* dan meningkatkan hasil kesehatan jangka panjang.

3.  **Audit Skema Penagihan Asuransi:**
    * **Rekomendasi:** Melakukan audit internal pada skema penagihan untuk pasien berasuransi untuk memahami mengapa rata-rata tagihannya lebih tinggi. Ini penting untuk memastikan transparansi dan hubungan baik dengan mitra asuransi.

4.  **Optimalisasi Kapasitas Departemen Bedah (*Surgery*):**
    * **Rekomendasi:** Mempelajari alur kerja di departemen "Surgery" yang memiliki durasi perawatan tercepat, dan mengidentifikasi apakah praktik efisiensi mereka dapat diterapkan di departemen lain seperti "General Medicine".